# Inflation keeps switching sides — v8 (bug-fix rebuild of v7)

## Run it

    python3 serve.py

then open http://127.0.0.1:8000

Open it through the server, not by double-clicking `index.html`. The page loads
CSV/GeoJSON with `fetch`, and browsers block that over `file://`.

## Story order

1. 2026 combined-inflation India map
2. Zoom to Telangana (highest, 6.32%)
3. Zoom to Mizoram (lowest, 1.84%)
4. Same map recolours to rural − urban
5. Zoom to Andaman & Nicobar (+1.73 pp)
6. Zoom to Himachal Pradesh (−1.18 pp)
7. 27 → 7 bounce
8. State gap dot plot
9. Rural vs urban averages
10. Combined inflation 2014–2025
11–13. Annual rural−urban gap, 2014 / 2016 / 2019
14. Every lead switch
15. Interactive CPI basket
16. Takeaway

## What changed from v7

### The zoom
v7 had two separate SVGs (`#combinedMap`, `#combinedZoomMap`) in two scenes and
cross-faded between them; each zoom step also reset to `scale(1)` first, so
Telangana → Mizoram snapped all the way out and back in.

v8 has ONE map (`#indiaMap` / `#mapZoom`). Scroll steps set a colour mode and a
focus state; the transform interpolates from wherever it is to the new target.
Steps 5 and 6 are gap stories, so they now use the gap colour scale (v7 showed
them on the combined scale).

Story-step attributes that drive it:

    data-visual="map" data-map-mode="combined|gap" data-map-focus="<State name>"

Omit `data-map-focus` to sit on the whole country.

Every step is `data-side="left"`, which puts the story card on the left and
pins the visual stage to the right for the whole piece, so nothing slides
sideways as you scroll. Setting a single step to `data-side="right"` still
works if you ever want to flip one.

### Layout
All widths derive from `--stage-w` in `style.css`:

    --card-w: min(calc(100vw - var(--stage-w) - rail-pad*2 - gutter), 540px)

Change `--stage-w` and the story card follows. v7 hard-coded 58vw + 39vw +
paddings, which overlapped by ~5-6vw on every step.

`.story` is `pointer-events:none` and `.story-card` is `pointer-events:auto`.
In v7 the full-width story sections sat over the stage and swallowed every
mouse event, so NO map or chart hover worked at all.

### Boundaries
`data/india-states.geojson` is bundled locally (36 states/UTs, dissolved from a
district-level source, named to match `inflation_2026.csv` exactly).

v7 fetched a remote 2011-era file that had no Andaman & Nicobar and no Ladakh
and spelled five units differently, so those states rendered grey and the
Andaman zoom step silently did nothing.

### Data handling
- All parsing goes through `num()`. v7 did `+d.gap` on Chandigarh's missing
  value, produced `NaN`, and `NaN !== null` passed the filters.
- Averages, the 27/7/1 split and the switch count are computed from the CSVs at
  runtime instead of typed into the HTML.
- NOTE: the 35 comparable states average rural 4.27%, urban 3.60%, gap 0.67 pp.
  v7's HTML said 3.62% and 0.65 pp. Verify against your workbook.
- The basket now lists all 7 categories. v7 omitted "Consumer Food Price",
  the -2.67 pp figure the step-15 copy cites.
- `switches.csv` holds 21 irregular dates, i.e. switch events, not months.
  Header changed from "MONTH BY MONTH" to "EVERY LEAD SWITCH". Its y-domain was
  [-2.9, 1.9] for data spanning -1.12..1.33; now [-1.6, 1.6].

### Charts
Each chart measures its container and draws in real pixels, with a debounced
resize redraw. v7 hard-coded viewBoxes like 1060x650 into near-square
containers, so every chart was letterboxed into a thin band.

The annual-gap chart had no event handlers at all in v7. All charts now have
mouse, click and touch handlers.

### Scroll
A rAF "which step owns the middle of the screen" test replaces the
IntersectionObserver at `threshold:.58` on `115vh` steps, which could fire for
two steps at once or skip steps on short viewports. One progress-bar writer
instead of two fighting each other.

## Files

    index.html                    story rail + visual stage
    style.css                     layout contract, scenes, responsive
    js/app.js                     data load, map, charts, scroll
    js/d3.v3.min.js               d3 v3 (unchanged)
    data/inflation_2026.csv       state-level 2026 rural/urban/combined/gap
    data/history_2014_2025.csv    annual rural, urban, gap
    data/annual_combined_2014_2025.csv
    data/switches.csv             lead-switch events
    data/decomposition.json       basket category gaps by period
    data/india-states.geojson     36 states/UTs
